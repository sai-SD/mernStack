import { useState } from 'react'
import SmallButton from './components/SmallButton'
import Navbar from './components/Navbar'
import FullBar from './components/FullBar'
function App() {
  const [count, setCount] = useState(0)
  return (
    <>
    <Navbar/>
    <SmallButton/>
    <FullBar/>
    </>
  )
}

export default App
