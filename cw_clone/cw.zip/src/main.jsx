import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
// import './index.css'
import { ChakraProvider } from '@chakra-ui/react'
import { extendTheme } from "@chakra-ui/react"

// const theme = extendTheme({
//   colors: {
//     brand: {
//       100: "#f7fafc",
//       // 200: "#475966",
//       // 300: "#FFFFFF",
//       // 500: "#FFFFFF",
//       // 400: "#FFFFFF",
//       // 600: "#FFFFFF",
//       // 700: "#FFFFFF",
//       // 800: "#FFFFFF",
//       900: "#1a202c",
//     },
//   },
// })

ReactDOM.createRoot(document.getElementById('root')).render(
  // <ChakraProvider theme={theme}>
  <ChakraProvider>
    <App />
  </ChakraProvider>
)