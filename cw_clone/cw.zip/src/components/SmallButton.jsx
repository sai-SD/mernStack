import React from 'react'
import { Button} from '@chakra-ui/react'
import './style.css'
const SmallButton = () => {
  return (
    <>
    <Button className='basicButton smallButton'>create an account now</Button>
    <br />
    <br />
    <Button className='basicButton smallButton full-768'>click here to login</Button>
    <br />
    <br />
    <Button className='basicButton mediumButton full-768'>login</Button>
    <br />
    <br />
    <Button className='basicButton largeButton full-768'>create an account</Button>
    <br />
    <br />
    </>
  )
}
export default SmallButton