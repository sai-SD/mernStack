import React from "react";
import './style.css'
const FullBar = () => {
  return (
    <>
      <div className="full-bar">
        <div className="fullBarContainer">
          <span className="fullBarText">
            We will keep you posted on new products and great offers
          </span>
          <div className="fullBarInputBox">
            <input type="email" placeholder="Email Address" />
          </div>
        </div>
      </div>
    </>
  );
};

export default FullBar;
